ArduinoM24SR
============

Arduino library for ST M24SR NFC dynamic tag
